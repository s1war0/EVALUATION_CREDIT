/**
 * riskAssessment.ts
 * =================
 * Unified risk assessment module that combines individual and company scoring.
 * Provides a single entry point for both assessment types.
 */

import { scoreIndividual, type IndividualClientInput, type RiskResult as IndividualRiskResult } from './individualRiskScorer';
import { scoreCompany, type CompanyClientInput, type RiskResult as CompanyRiskResult } from './companyRiskScorer';

export type AssessmentType = 'individual' | 'company';

export interface AssessmentResult {
  type: AssessmentType;
  score: number;
  risk_level: string;
  probability?: number;
  explanation?: any[];
  altman_z_score?: number;
  basel_iii?: any;
}

/**
 * Unified assessment function that handles both individual and company scoring
 */
export function assessRisk(
  type: AssessmentType,
  input: IndividualClientInput | CompanyClientInput
): AssessmentResult {
  if (type === 'individual') {
    const result = scoreIndividual(input as IndividualClientInput);
    return {
      type: 'individual',
      score: result.risk_score,
      risk_level: result.risk_level,
      probability: result.probability,
      explanation: result.explanation,
    };
  } else if (type === 'company') {
    const result = scoreCompany(input as CompanyClientInput);
    return {
      type: 'company',
      score: result.risk_score,
      risk_level: result.risk_level,
      probability: result.probability,
      explanation: result.explanation,
      altman_z_score: result.altman_z_score,
      basel_iii: result.basel_iii,
    };
  }
  throw new Error(`Unknown assessment type: ${type}`);
}
