import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, TrendingUp, BarChart3, Lock } from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100">
      {/* Navigation Header */}
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-slate-900">CreditRisk Pro</span>
          </div>
          <Button onClick={() => setLocation("/risk")} className="gap-2">
            Get Started <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-6xl mx-auto px-6 py-20 text-center">
        <div className="mb-8">
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6 leading-tight">
            Advanced Credit Risk Assessment
          </h1>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto mb-8">
            Evaluate credit risk for individuals and companies using state-of-the-art machine learning models with proven accuracy
          </p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white rounded-lg border border-slate-200 p-6 shadow-sm hover:shadow-md transition-shadow">
            <div className="text-3xl font-bold text-blue-600 mb-2">0.974</div>
            <p className="text-slate-600 font-medium">Company Model AUC</p>
            <p className="text-sm text-slate-500 mt-2">Based on 197 S&P firms</p>
          </div>
          <div className="bg-white rounded-lg border border-slate-200 p-6 shadow-sm hover:shadow-md transition-shadow">
            <div className="text-3xl font-bold text-emerald-600 mb-2">0.866</div>
            <p className="text-slate-600 font-medium">Individual Model AUC</p>
            <p className="text-sm text-slate-500 mt-2">Based on 150K samples</p>
          </div>
          <div className="bg-white rounded-lg border border-slate-200 p-6 shadow-sm hover:shadow-md transition-shadow">
            <div className="text-3xl font-bold text-purple-600 mb-2">5</div>
            <p className="text-slate-600 font-medium">Risk Categories</p>
            <p className="text-sm text-slate-500 mt-2">From Very Low to Very High</p>
          </div>
        </div>

        {/* CTA Button */}
        <Button
          onClick={() => setLocation("/risk")}
          size="lg"
          className="gap-2 mb-16 text-lg px-8 py-6"
        >
          Start Assessment <ArrowRight className="w-5 h-5" />
        </Button>
      </section>

      {/* Features Section */}
      <section className="bg-white border-t border-slate-200 py-20">
        <div className="max-w-6xl mx-auto px-6">
          <h2 className="text-3xl font-bold text-slate-900 text-center mb-12">Comprehensive Risk Analysis</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Individual Assessment */}
            <div className="p-8 rounded-lg border border-slate-200 bg-gradient-to-br from-blue-50 to-white">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">Individual Assessment</h3>
              <ul className="space-y-2 text-slate-600 mb-6">
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 font-bold">•</span>
                  <span>Credit utilization analysis</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 font-bold">•</span>
                  <span>Payment history evaluation</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 font-bold">•</span>
                  <span>Income and debt ratio assessment</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 font-bold">•</span>
                  <span>Instant risk scoring</span>
                </li>
              </ul>
              <Button
                onClick={() => setLocation("/risk/individual")}
                variant="outline"
                className="w-full"
              >
                Assess Individual
              </Button>
            </div>

            {/* Company Assessment */}
            <div className="p-8 rounded-lg border border-slate-200 bg-gradient-to-br from-emerald-50 to-white">
              <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4">
                <BarChart3 className="w-6 h-6 text-emerald-600" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">Company Assessment</h3>
              <ul className="space-y-2 text-slate-600 mb-6">
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 font-bold">•</span>
                  <span>Altman Z-Score calculation</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 font-bold">•</span>
                  <span>Basel III compliance check</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 font-bold">•</span>
                  <span>Financial ratio analysis</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-emerald-600 font-bold">•</span>
                  <span>Enterprise risk evaluation</span>
                </li>
              </ul>
              <Button
                onClick={() => setLocation("/risk/company")}
                variant="outline"
                className="w-full"
              >
                Assess Company
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Security Section */}
      <section className="py-20 bg-slate-50 border-t border-slate-200">
        <div className="max-w-6xl mx-auto px-6 text-center">
          <div className="w-12 h-12 bg-slate-200 rounded-lg flex items-center justify-center mx-auto mb-4">
            <Lock className="w-6 h-6 text-slate-600" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-4">Enterprise-Grade Security</h2>
          <p className="text-slate-600 max-w-2xl mx-auto">
            All assessments are processed securely with industry-standard encryption. Your data is never stored or shared.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-8">
        <div className="max-w-6xl mx-auto px-6 text-center text-slate-600 text-sm">
          <p>CreditRisk Pro - Advanced Credit Risk Assessment Platform</p>
          <p className="mt-2">Powered by machine learning models with proven accuracy</p>
        </div>
      </footer>
    </div>
  );
}
