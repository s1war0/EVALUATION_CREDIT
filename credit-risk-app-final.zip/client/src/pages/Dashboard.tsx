import { Link } from "wouter";
import { ArrowLeft, History, TrendingUp, ShieldCheck, AlertTriangle, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = trpc.risk.getStats.useQuery();
  const { data: history, isLoading: historyLoading } = trpc.risk.getHistory.useQuery();

  const COLORS = ['#10b981', '#f59e0b', '#ef4444']; // Green, Amber, Red

  const getRiskDistribution = () => {
    if (!history) return [];
    const counts = { 'Low': 0, 'Medium': 0, 'High': 0 };
    history.forEach(h => {
      const level = h.riskLevel as keyof typeof counts;
      if (counts[level] !== undefined) counts[level]++;
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  };

  const getScoreTrends = () => {
    if (!history) return [];
    return [...history]
      .reverse()
      .slice(-10)
      .map(h => ({
        date: new Date(h.createdAt).toLocaleDateString(),
        score: h.score
      }));
  };

  if (statsLoading || historyLoading) {
    return (
      <div className="container mx-auto py-8 px-4 space-y-8">
        <Skeleton className="h-12 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
        </div>
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4 space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-3xl font-bold tracking-tight">Tableau de Bord</h1>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Évaluations</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.total || 0}</div>
            <p className="text-xs text-muted-foreground">Analyses effectuées à ce jour</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Score Moyen</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.avgScore || 0}</div>
            <p className="text-xs text-muted-foreground">Moyenne de risque globale</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Statut Système</CardTitle>
            <ShieldCheck className="h-4 w-4 text-emerald-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-500">Actif</div>
            <p className="text-xs text-muted-foreground">Moteur de scoring opérationnel</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Score Trends */}
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Évolution des Scores</CardTitle>
            <CardDescription>Historique des 10 dernières évaluations</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            {history && history.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={getScoreTrends()}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="date" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis fontSize={12} tickLine={false} axisLine={false} domain={[0, 100]} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: '1px solid #e2e8f0' }}
                  />
                  <Bar dataKey="score" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                <p>Aucune donnée disponible</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Risk Distribution */}
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Répartition des Risques</CardTitle>
            <CardDescription>Distribution par niveau de risque</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            {history && history.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={getRiskDistribution()}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {getRiskDistribution().map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                <p>Aucune donnée disponible</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* History Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <History className="h-5 w-5" />
            <CardTitle>Historique des Évaluations</CardTitle>
          </div>
          <CardDescription>Liste complète de vos analyses de risque</CardDescription>
        </CardHeader>
        <CardContent>
          {history && history.length > 0 ? (
            <div className="relative w-full overflow-auto">
              <table className="w-full caption-bottom text-sm">
                <thead className="[&_tr]:border-b">
                  <tr className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                    <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Date</th>
                    <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Type</th>
                    <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Score</th>
                    <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Risque</th>
                  </tr>
                </thead>
                <tbody className="[&_tr:last-child]:border-0">
                  {history.map((h) => (
                    <tr key={h.id} className="border-b transition-colors hover:bg-muted/50">
                      <td className="p-4 align-middle">{new Date(h.createdAt).toLocaleDateString()}</td>
                      <td className="p-4 align-middle capitalize">{h.type === 'individual' ? 'Particulier' : 'Entreprise'}</td>
                      <td className="p-4 align-middle font-semibold">{h.score}</td>
                      <td className="p-4 align-middle">
                        <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                          h.riskLevel === 'Low' ? 'bg-emerald-100 text-emerald-800' :
                          h.riskLevel === 'Medium' ? 'bg-amber-100 text-amber-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {h.riskLevel}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <AlertTriangle className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">Aucune évaluation</h3>
              <p className="text-sm text-muted-foreground mb-6">Commencez par évaluer un client ou une entreprise.</p>
              <Link href="/hub">
                <Button>Nouvelle Évaluation</Button>
              </Link>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
