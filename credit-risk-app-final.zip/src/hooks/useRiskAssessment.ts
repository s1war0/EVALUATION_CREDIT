/**
 * useRiskAssessment.ts
 * =====================
 * React hook — wraps the risk scorer for use in your form/UI.
 *
 * Usage:
 *   import { useRiskAssessment } from '@/hooks/useRiskAssessment';
 *
 *   function RiskForm() {
 *     const { score, result, isLoading, reset } = useRiskAssessment('individual');
 *
 *     const handleSubmit = async (formData) => {
 *       await score(formData);
 *     };
 *
 *     return (
 *       <div>
 *         <button onClick={() => score({ age: 35, monthly_income: 5000 })}>
 *           Assess Risk
 *         </button>
 *         {result && (
 *           <div style={{ color: result.data.color }}>
 *             {result.data.risk_level} — Score: {result.data.risk_score}/100
 *           </div>
 *         )}
 *       </div>
 *     );
 *   }
 */

import { useState, useCallback } from 'react';
import { assessRisk }            from '../lib/risk/riskAssessment';
import type { IndividualClientInput } from '../lib/risk/individualRiskScorer';
import type { CompanyInput }          from '../lib/risk/companyRiskScorer';
import type { AssessmentResult, ClientType } from '../lib/risk/riskAssessment';

interface UseRiskAssessmentReturn<T> {
  /** Run scoring (synchronous — instant result) */
  score: (input: T) => void;
  /** Latest assessment result */
  result: AssessmentResult | null;
  /** Loading state (always false — scoring is synchronous) */
  isLoading: boolean;
  /** Error message if something went wrong */
  error: string | null;
  /** Reset to initial state */
  reset: () => void;
}

export function useRiskAssessment(type: 'individual'): UseRiskAssessmentReturn<IndividualClientInput>;
export function useRiskAssessment(type: 'company'):    UseRiskAssessmentReturn<CompanyInput>;
export function useRiskAssessment(type: ClientType): UseRiskAssessmentReturn<any> {
  const [result,    setResult]    = useState<AssessmentResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error,     setError]     = useState<string | null>(null);

  const score = useCallback((input: IndividualClientInput | CompanyInput) => {
    setIsLoading(true);
    setError(null);
    try {
      const res = type === 'individual'
        ? assessRisk('individual', input as IndividualClientInput)
        : assessRisk('company',    input as CompanyInput);
      setResult(res);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Scoring failed');
    } finally {
      setIsLoading(false);
    }
  }, [type]);

  const reset = useCallback(() => {
    setResult(null);
    setError(null);
  }, []);

  return { score, result, isLoading, error, reset };
}
