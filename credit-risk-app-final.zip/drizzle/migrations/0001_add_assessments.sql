-- Create assessments table for storing risk assessment results
CREATE TABLE IF NOT EXISTS `assessments` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `userId` int,
  `type` enum('individual', 'company') NOT NULL,
  `inputData` text NOT NULL,
  `resultData` text NOT NULL,
  `score` int NOT NULL,
  `riskLevel` varchar(20) NOT NULL,
  `createdAt` timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL,
  FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_userId_createdAt` (`userId`, `createdAt`),
  INDEX `idx_type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
