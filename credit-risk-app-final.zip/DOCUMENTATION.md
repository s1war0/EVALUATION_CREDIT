# Documentation Complète - Credit Risk Assessment Application

## Vue d'Ensemble

**Credit Risk Assessment Application** est une plateforme web professionnelle permettant d'évaluer le risque de crédit pour les particuliers et les entreprises. L'application utilise des modèles de machine learning entraînés (Logistic Regression) pour calculer des scores de risque précis, complétés par des analyses financières avancées comme le Z-Score d'Altman et les ratios de conformité Basel III.

### Caractéristiques Principales

- **Scoring Individuel** : Évaluation du risque de crédit pour les particuliers basée sur 10 facteurs clés
- **Scoring Entreprise** : Analyse financière complète incluant 16 métriques financières
- **Calculs Avancés** : Z-Score d'Altman et conformité Basel III pour les entreprises
- **Tableau de Bord Analytique** : Visualisation des tendances et historique des évaluations
- **Persistance des Données** : Stockage sécurisé des évaluations en base de données MySQL
- **Authentification OAuth** : Intégration Manus OAuth pour la gestion des utilisateurs

## Architecture Technique

### Stack Technologique

| Composant | Technologie |
|-----------|------------|
| Frontend | Vite + React 19 + TypeScript |
| Backend | Express + tRPC |
| Base de Données | MySQL + Drizzle ORM |
| Authentification | Manus OAuth |
| UI Components | Shadcn/ui + TailwindCSS |
| Graphiques | Recharts |
| Validation | Zod |
| Tests | Vitest |

### Structure du Projet

```
credit-risk-app/
├── client/                          # Frontend React
│   ├── src/
│   │   ├── pages/                  # Pages principales
│   │   │   ├── Home.tsx            # Page d'accueil
│   │   │   ├── RiskHub.tsx         # Hub de sélection
│   │   │   ├── IndividualAssessment.tsx
│   │   │   ├── CompanyAssessment.tsx
│   │   │   └── Dashboard.tsx       # Tableau de bord analytique
│   │   ├── components/             # Composants réutilisables
│   │   ├── lib/                    # Utilitaires et logique métier
│   │   │   └── risk/               # Scoreurs ML
│   │   └── main.tsx
│   └── index.html
├── server/                          # Backend Express + tRPC
│   ├── routers.ts                  # Routeurs tRPC
│   ├── db.ts                       # Couche d'accès aux données
│   └── _core/                      # Configuration et utilitaires
├── drizzle/                         # Migrations et schéma
│   ├── schema.ts                   # Définition des tables
│   └── migrations/                 # Fichiers de migration SQL
├── shared/                          # Code partagé client/serveur
└── src/                            # Code ML et utilitaires
    └── lib/risk/
        ├── individualRiskScorer.ts # Scoring particuliers
        ├── companyRiskScorer.ts    # Scoring entreprises
        ├── riskAssessment.ts       # Wrapper unifié
        └── *.json                  # Poids des modèles ML
```

## Modules Clés

### 1. Scoring Individuel (`individualRiskScorer.ts`)

Évalue le risque de crédit pour les particuliers en utilisant une régression logistique entraînée.

**Facteurs d'entrée :**
- `age` : Âge du demandeur (18-120 ans)
- `monthly_income` : Revenu mensuel brut
- `credit_utilization_ratio` : Ratio d'utilisation du crédit (0-1)
- `debt_to_income_ratio` : Ratio dette/revenu
- `open_credit_lines` : Nombre de lignes de crédit ouvertes
- `times_90_days_late` : Nombre de retards de 90+ jours
- `times_60_89_days_late` : Nombre de retards de 60-89 jours
- `times_30_59_days_late` : Nombre de retards de 30-59 jours
- `real_estate_loans` : Nombre de prêts immobiliers
- `number_of_dependents` : Nombre de personnes à charge

**Résultat :**
```typescript
{
  probability: number;           // Probabilité de défaut (0-1)
  risk_level: RiskLevel;         // LOW, MEDIUM, HIGH, VERY_HIGH
  risk_score: number;            // Score de sécurité (0-100)
  color: string;                 // Couleur pour affichage UI
  explanation: FactorExplanation[]; // Facteurs contributifs
}
```

### 2. Scoring Entreprise (`companyRiskScorer.ts`)

Analyse financière complète incluant scoring ML, Z-Score d'Altman et conformité Basel III.

**Facteurs d'entrée :**
- Ratios de capital : `common_equity_ratio`, `capital_adequacy_ratio`
- Ratios de rentabilité : `roe`, `ebit_ratio`, `net_profit_margin`
- Ratios de liquidité : `liq_assets_ratio`, `lcr`
- Ratios de solvabilité : `equity_to_debt`, `leverage_ratio`
- Ratios opérationnels : `cost_to_income`, `loan_loss_provisions`
- Ratios de croissance : `size_log_assets`, `sales_ratio`
- Autres : `working_capital_ratio`, `retained_earnings_ratio`, `debt_service_coverage`

**Résultat :**
```typescript
{
  // Scoring ML standard
  probability: number;
  risk_level: RiskLevel;
  risk_score: number;
  
  // Z-Score d'Altman
  altman_z_score: number;
  altman_interpretation: string;
  
  // Conformité Basel III
  basel_iii: {
    capital_adequacy_ratio: number;
    tier1_ratio: number;
    liquidity_coverage_ratio: number;
    compliant: boolean;
    violations: string[];
  }
}
```

### 3. Persistance des Données

**Table `assessments` :**
```sql
CREATE TABLE assessments (
  id INT PRIMARY KEY AUTO_INCREMENT,
  userId INT REFERENCES users(id),
  type ENUM('individual', 'company'),
  inputData TEXT,           -- JSON des paramètres d'entrée
  resultData TEXT,          -- JSON du résultat complet
  score INT,                -- Score numérique
  riskLevel VARCHAR(20),    -- Niveau de risque
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**Requêtes disponibles :**
- `createAssessment()` : Enregistrer une nouvelle évaluation
- `getAssessmentsByUserId()` : Récupérer l'historique d'un utilisateur
- `getAssessmentStats()` : Obtenir les statistiques (total, moyenne, récents)

### 4. API tRPC

**Endpoints disponibles :**

```typescript
// Scoring
POST /trpc/risk.scoreIndividual
  Input: IndividualClientInput
  Output: AssessmentResult

POST /trpc/risk.scoreCompany
  Input: CompanyClientInput
  Output: AssessmentResult

// Récupération des données
GET /trpc/risk.getStats
  Output: { total: number, avgScore: number, recent: Assessment[] }

GET /trpc/risk.getHistory
  Output: Assessment[]
```

## Interfaces Utilisateur

### 1. Page d'Accueil (`Home.tsx`)

Présentation professionnelle de l'application avec :
- Proposition de valeur claire
- Boutons d'accès aux deux types d'évaluation
- Lien vers le tableau de bord
- Design moderne et épuré

### 2. Hub de Sélection (`RiskHub.tsx`)

Point d'entrée pour choisir entre :
- Évaluation d'un particulier
- Évaluation d'une entreprise
- Accès au tableau de bord

### 3. Évaluation Individuelle (`IndividualAssessment.tsx`)

Formulaire structuré en sections :
- Informations personnelles (âge, revenu)
- Informations de crédit (utilisation, ratio dette/revenu)
- Historique de paiement (retards)
- Informations supplémentaires (prêts immobiliers, dépendants)

Validation en temps réel et affichage des résultats avec :
- Score de risque avec jauge visuelle
- Niveau de risque colorisé
- Facteurs contributifs principaux
- Résumé analytique

### 4. Évaluation Entreprise (`CompanyAssessment.tsx`)

Formulaire complet avec :
- Ratios de capital et liquidité
- Métriques de rentabilité
- Ratios de solvabilité
- Métriques Altman et Basel III

Résultats incluant :
- Score de risque ML
- Z-Score d'Altman avec interprétation
- Conformité Basel III avec violations
- Facteurs de risque détaillés

### 5. Tableau de Bord (`Dashboard.tsx`)

Visualisation analytique avec :
- **KPIs** : Total évaluations, score moyen, statut système
- **Graphiques** :
  - Évolution des scores (graphique en barres)
  - Répartition des risques (graphique en camembert)
- **Historique** : Tableau complet des évaluations avec filtrage

## Tests

### Suites de Tests

**13 tests au total, tous passants :**

#### Scoring Individuel (5 tests)
- ✓ Scoring bas risque
- ✓ Scoring haut risque
- ✓ Imputation des valeurs manquantes
- ✓ Résumé des facteurs
- ✓ Facteurs contributifs

#### Scoring Entreprise (7 tests)
- ✓ Scoring de base
- ✓ Calcul Z-Score d'Altman
- ✓ Conformité Basel III
- ✓ Violations Basel III
- ✓ Facteurs contributifs
- ✓ Interprétation Altman
- ✓ Résumé des facteurs

#### Authentification (1 test)
- ✓ Logout utilisateur

### Exécution des Tests

```bash
# Installer les dépendances
pnpm install

# Exécuter tous les tests
pnpm test

# Mode watch
pnpm test:watch
```

## Installation et Déploiement

### Prérequis

- Node.js 22.13.0+
- pnpm 10.4.1+
- MySQL 8.0+
- Compte Manus OAuth

### Installation Locale

```bash
# Cloner le projet
git clone <repository-url>
cd credit-risk-app

# Installer les dépendances
pnpm install

# Configurer les variables d'environnement
cp .env.example .env.local

# Exécuter les migrations
pnpm drizzle-kit migrate

# Démarrer le serveur de développement
pnpm dev
```

### Variables d'Environnement

```env
# Base de données
DATABASE_URL=mysql://user:password@localhost:3306/credit_risk

# OAuth Manus
MANUS_CLIENT_ID=<your-client-id>
MANUS_CLIENT_SECRET=<your-client-secret>
MANUS_REDIRECT_URI=http://localhost:5173/auth/callback

# Serveur
NODE_ENV=development
PORT=3000
```

### Build Production

```bash
# Build frontend et backend
pnpm build

# Démarrer le serveur de production
pnpm start
```

## Modèles de Machine Learning

### Scoring Individuel

**Modèle** : Régression Logistique
**Poids** : Stockés dans `individual_scoring_weights.json`

Facteurs clés :
1. Retards de paiement (poids élevé)
2. Ratio d'utilisation du crédit
3. Ratio dette/revenu
4. Nombre de lignes de crédit
5. Âge et revenu

### Scoring Entreprise

**Modèle** : Régression Logistique + Analyses Financières
**Poids** : Stockés dans `company_scoring_weights.json`

Facteurs clés :
1. Ratios de capital (Basel III)
2. Rentabilité (ROE, EBIT)
3. Liquidité (LCR, ratios d'actifs)
4. Solvabilité (Equity/Debt, Leverage)
5. Efficacité opérationnelle (Cost-to-Income)

### Z-Score d'Altman

Formule : Z = 1.2X₁ + 1.4X₂ + 3.3X₃ + 0.6X₄ + 1.0X₅

Où :
- X₁ = Working Capital / Total Assets
- X₂ = Retained Earnings / Total Assets
- X₃ = EBIT / Total Assets
- X₄ = Market Value of Equity / Total Liabilities
- X₅ = Sales / Total Assets

Interprétation :
- Z > 2.99 : Zone sûre (faible risque)
- 1.81 < Z < 2.99 : Zone grise (risque modéré)
- Z < 1.81 : Zone de détresse (risque élevé)

### Conformité Basel III

Ratios vérifiés :
- **Capital Adequacy Ratio** : ≥ 10.5%
- **Tier 1 Ratio** : ≥ 8.5%
- **Liquidity Coverage Ratio** : ≥ 100%

## Support et Maintenance

### Logs

Les logs d'application sont disponibles dans :
- Console serveur pour les erreurs backend
- Console navigateur pour les erreurs frontend
- Fichiers de log (si configurés)

### Monitoring

Points de surveillance recommandés :
- Temps de réponse des évaluations
- Taux d'erreur du scoring
- Utilisation de la base de données
- Performance des graphiques du dashboard

### Mises à Jour

Pour mettre à jour les modèles ML :
1. Remplacer les fichiers JSON de poids
2. Mettre à jour les versions dans les fichiers TypeScript
3. Exécuter les tests pour valider
4. Déployer la nouvelle version

## Dépannage

### Erreur : "Database not available"

**Solution** : Vérifier que `DATABASE_URL` est configurée et que MySQL est accessible.

### Erreur : "Failed to load risk assessment"

**Solution** : Vérifier que les fichiers JSON de poids existent dans `src/lib/risk/`.

### Évaluations non sauvegardées

**Solution** : Vérifier que l'utilisateur est authentifié et que la table `assessments` existe en base de données.

### Graphiques du dashboard vides

**Solution** : Effectuer au moins une évaluation pour générer des données. Vérifier que `getHistory` retourne des résultats.

## Conformité et Sécurité

- **HTTPS** : Obligatoire en production
- **Authentification** : OAuth Manus
- **Chiffrement** : Données sensibles chiffrées en transit
- **Validation** : Zod pour validation côté client et serveur
- **Audit** : Historique complet des évaluations avec timestamps

## Licence et Attribution

Cette application utilise :
- **Shadcn/ui** : Composants UI open-source
- **Recharts** : Bibliothèque de graphiques
- **Drizzle ORM** : ORM TypeScript
- **tRPC** : Framework RPC type-safe

## Changelog

### Version 1.0.0 (2026-04-07)

**Fonctionnalités principales :**
- Scoring individuel avec 10 facteurs
- Scoring entreprise avec 16 métriques
- Z-Score d'Altman pour entreprises
- Conformité Basel III
- Tableau de bord analytique
- Persistance des données
- Authentification OAuth
- 13 tests unitaires (tous passants)

**Améliorations futures :**
- Export des rapports en PDF
- Comparaison d'évaluations
- Alertes de risque
- Intégration API externe
- Mobile app native

---

**Document généré le** : 2026-04-07
**Version** : 1.0.0
**Statut** : Production Ready
