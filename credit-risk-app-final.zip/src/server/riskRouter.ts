/**
 * riskRouter.ts
 * ==============
 * tRPC router — add this to your existing tRPC setup.
 *
 * 1. Copy this file to:  src/server/routers/riskRouter.ts
 * 2. In your root router (src/server/routers/index.ts), add:
 *      import { riskRouter } from './riskRouter';
 *      export const appRouter = router({ ..., risk: riskRouter });
 * 3. In your React component, call:
 *      const utils = api.useUtils();
 *      const { mutate } = api.risk.scoreIndividual.useMutation();
 */

import { z }       from 'zod';
// import { router, publicProcedure } from '../trpc'; // adjust path to your trpc setup
import { assessRisk } from '../../lib/risk/riskAssessment';

// Mocking tRPC for now since it's not present in the project
const router = (obj: any) => obj;
const publicProcedure = {
  input: (schema: any) => ({
    mutation: (cb: any) => cb
  })
};

// ── Zod schemas ────────────────────────────────────────────────────────────

const IndividualSchema = z.object({
  age:                      z.number().min(18).max(120).optional(),
  monthly_income:           z.number().min(0).optional(),
  credit_utilization_ratio: z.number().min(0).max(1).optional(),
  debt_to_income_ratio:     z.number().min(0).optional(),
  open_credit_lines:        z.number().int().min(0).optional(),
  times_90_days_late:       z.number().int().min(0).optional(),
  times_60_89_days_late:    z.number().int().min(0).optional(),
  times_30_59_days_late:    z.number().int().min(0).optional(),
  real_estate_loans:        z.number().int().min(0).optional(),
  number_of_dependents:     z.number().int().min(0).optional(),
});

const CompanySchema = z.object({
  common_equity_ratio:       z.number().optional(),
  loan_loss_provisions:      z.number().optional(),
  cost_to_income:            z.number().optional(),
  roe:                       z.number().optional(),
  liq_assets_ratio:          z.number().optional(),
  size_log_assets:           z.number().optional(),
  working_capital_ratio:     z.number().optional(),
  retained_earnings_ratio:   z.number().optional(),
  ebit_ratio:                z.number().optional(),
  equity_to_debt:            z.number().optional(),
  sales_ratio:               z.number().optional(),
  capital_adequacy_ratio:    z.number().optional(),
  leverage_ratio:            z.number().optional(),
  lcr:                       z.number().optional(),
  debt_service_coverage:     z.number().optional(),
  net_profit_margin:         z.number().optional(),
});

// ── Router ─────────────────────────────────────────────────────────────────

export const riskRouter = router({
  /** Score an individual client */
  scoreIndividual: publicProcedure
    .input(IndividualSchema)
    .mutation(({ input }: { input: any }) => {
      const result = assessRisk('individual', input);
      return result;
    }),

  /** Score a company */
  scoreCompany: publicProcedure
    .input(CompanySchema)
    .mutation(({ input }: { input: any }) => {
      const result = assessRisk('company', input);
      return result;
    }),

  /** Score either type with a discriminated union */
  score: publicProcedure
    .input(z.discriminatedUnion('type', [
      z.object({ type: z.literal('individual'), data: IndividualSchema }),
      z.object({ type: z.literal('company'),    data: CompanySchema    }),
    ]))
    .mutation(({ input }: { input: any }) => {
      if (input.type === 'individual') return assessRisk('individual', input.data);
      return assessRisk('company', input.data);
    }),
});
