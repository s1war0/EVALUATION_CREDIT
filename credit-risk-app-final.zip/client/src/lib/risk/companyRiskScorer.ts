/**
 * companyRiskScorer.ts
 * =====================
 * Risk scorer for companies/enterprises.
 * Uses Altman Z-Score + Basel III ratios + trained LR weights.
 * Pure TypeScript — no server needed.
 *
 * Usage:
 *   import { scoreCompany, computeAltmanZ, computeBaselRatios } from './companyRiskScorer';
 *   const result = scoreCompany({ roe: 0.12, liq_assets_ratio: 0.25, ... });
 */

import weights from './company_scoring_weights.json';

// ── Types ──────────────────────────────────────────────────────────────────

export interface CompanyInput {
  // ── Core financial ratios (most important) ──
  /** Common Equity / Total Assets  (e.g. 0.08 = 8%) */
  common_equity_ratio?: number;
  /** Loan Loss Provisions / Total Loans  (e.g. 0.005) */
  loan_loss_provisions?: number;
  /** Operating Costs / Operating Income  (e.g. 0.65) */
  cost_to_income?: number;
  /** Return on Equity  (e.g. 0.12 = 12%) */
  roe?: number;
  /** Liquid Assets / Total Assets  (e.g. 0.20) */
  liq_assets_ratio?: number;
  /** Natural log of Total Assets  (e.g. log(1B USD) ≈ 20.7) */
  size_log_assets?: number;

  // ── Altman Z-Score components ──
  /** X1: Working Capital / Total Assets */
  working_capital_ratio?: number;
  /** X2: Retained Earnings / Total Assets */
  retained_earnings_ratio?: number;
  /** X3: EBIT / Total Assets */
  ebit_ratio?: number;
  /** X4: Market Value of Equity / Book Value of Liabilities */
  equity_to_debt?: number;
  /** X5: Sales / Total Assets */
  sales_ratio?: number;

  // ── Basel III ──
  /** Capital Adequacy Ratio (Tier1+Tier2 / RWA). Min: 10.5% */
  capital_adequacy_ratio?: number;
  /** Leverage Ratio (Tier1 / Total Assets). Min: 3% */
  leverage_ratio?: number;
  /** Liquidity Coverage Ratio proxy. Min: 100% (=1.0) */
  lcr?: number;

  // ── Additional ──
  /** EBIT / Total Debt Service */
  debt_service_coverage?: number;
  /** Net Income / Revenue */
  net_profit_margin?: number;
}

export type RiskLevel = 'VERY_LOW' | 'LOW' | 'MEDIUM' | 'HIGH' | 'VERY_HIGH';

export interface AltmanResult {
  z_score: number;
  zone: 'safe' | 'grey' | 'distress';
  zone_label: string;
  color: string;
  components: { name: string; value: number; weight: number; contribution: number }[];
}

export interface BaselResult {
  car_ok: boolean;
  leverage_ok: boolean;
  lcr_ok: boolean;
  violations: string[];
  all_compliant: boolean;
}

export interface CompanyRiskResult {
  probability: number;
  risk_level: RiskLevel;
  risk_score: number;
  color: string;
  altman: AltmanResult;
  basel: BaselResult;
  explanation: FactorExplanation[];
  flags: string[];
}

export interface FactorExplanation {
  feature: string;
  value: number;
  direction: 'increases_risk' | 'decreases_risk' | 'neutral';
  weight: number;
}

// ── Constants ──────────────────────────────────────────────────────────────

const RISK_COLORS: Record<RiskLevel, string> = {
  VERY_LOW:  '#22c55e',
  LOW:       '#84cc16',
  MEDIUM:    '#f59e0b',
  HIGH:      '#f97316',
  VERY_HIGH: '#ef4444',
};

const FEATURE_MAP: Record<string, keyof CompanyInput> = {
  COMMEQTA:               'common_equity_ratio',
  LLPLOANS:               'loan_loss_provisions',
  COSTTOINCOME:           'cost_to_income',
  ROE:                    'roe',
  LIQASSTA:               'liq_assets_ratio',
  SIZE:                   'size_log_assets',
  working_capital_ratio:  'working_capital_ratio',
  retained_earnings_ratio:'retained_earnings_ratio',
  ebit_ratio:             'ebit_ratio',
  equity_to_debt:         'equity_to_debt',
  sales_ratio:            'sales_ratio',
  altman_z:               undefined as any, // computed
  car_ratio:              'capital_adequacy_ratio',
  leverage_ratio:         'leverage_ratio',
  lcr_proxy:              'lcr',
  debt_service_coverage:  'debt_service_coverage',
  net_profit_margin:      'net_profit_margin',
};

// ── Altman Z-Score ─────────────────────────────────────────────────────────

export function computeAltmanZ(input: CompanyInput): AltmanResult {
  const X1 = input.working_capital_ratio  ?? 0.1;
  const X2 = input.retained_earnings_ratio?? 0.15;
  const X3 = input.ebit_ratio             ?? 0.05;
  const X4 = input.equity_to_debt        ?? 1.0;
  const X5 = input.sales_ratio            ?? 0.8;

  const components = [
    { name: 'Working Capital / Assets (X1)', value: X1, weight: 1.2,  contribution: 1.2  * X1 },
    { name: 'Retained Earnings / Assets (X2)', value: X2, weight: 1.4, contribution: 1.4  * X2 },
    { name: 'EBIT / Assets (X3)',          value: X3, weight: 3.3,  contribution: 3.3  * X3 },
    { name: 'Equity / Debt (X4)',          value: X4, weight: 0.6,  contribution: 0.6  * X4 },
    { name: 'Sales / Assets (X5)',         value: X5, weight: 0.99, contribution: 0.99 * X5 },
  ];

  const z = components.reduce((sum, c) => sum + c.contribution, 0);

  let zone: AltmanResult['zone'];
  let zone_label: string;
  let color: string;

  if (z > 2.99) {
    zone = 'safe'; zone_label = 'Safe Zone (low default risk)'; color = '#22c55e';
  } else if (z >= 1.81) {
    zone = 'grey'; zone_label = 'Grey Zone (moderate risk)'; color = '#f59e0b';
  } else {
    zone = 'distress'; zone_label = 'Distress Zone (high default risk)'; color = '#ef4444';
  }

  return { z_score: Math.round(z * 1000) / 1000, zone, zone_label, color, components };
}

// ── Basel III Compliance ───────────────────────────────────────────────────

export function computeBaselRatios(input: CompanyInput): BaselResult {
  const car = input.capital_adequacy_ratio ?? input.common_equity_ratio;
  const lev = input.leverage_ratio;
  const lcr = input.lcr;

  const car_ok = car != null ? car >= 0.105 : true; // unknown → assume ok
  const leverage_ok = lev != null ? lev >= 0.03 : true;
  const lcr_ok = lcr != null ? lcr >= 1.0 : true;

  const violations: string[] = [];
  if (!car_ok) violations.push(`CAR ${(car! * 100).toFixed(1)}% < 10.5% minimum`);
  if (!leverage_ok) violations.push(`Leverage ${(lev! * 100).toFixed(1)}% < 3% minimum`);
  if (!lcr_ok) violations.push(`LCR ${lcr!.toFixed(2)} < 1.0 minimum`);

  return { car_ok, leverage_ok, lcr_ok, violations, all_compliant: violations.length === 0 };
}

// ── Core math ──────────────────────────────────────────────────────────────

function sigmoid(x: number): number {
  return 1 / (1 + Math.exp(-x));
}

function getVal(input: CompanyInput, internalKey: string, altmanZ: number): number {
  if (internalKey === 'altman_z') return altmanZ;

  const appKey = FEATURE_MAP[internalKey];
  const raw = appKey ? input[appKey] : undefined;
  const median = (weights.scaler_mean as any)[internalKey] ?? 0;
  return raw != null ? Number(raw) : median;
}

// ── Main scorer ────────────────────────────────────────────────────────────

export function scoreCompany(input: CompanyInput): CompanyRiskResult {
  const altman = computeAltmanZ(input);
  const basel  = computeBaselRatios(input);

  // Build feature vector
  let logit = weights.intercept;
  const contributions: { feature: string; value: number; contribution: number }[] = [];

  for (const feat of weights.feature_order) {
    const raw  = getVal(input, feat, altman.z_score);
    const mean = (weights.scaler_mean as any)[feat] ?? 0;
    const std  = (weights.scaler_std  as any)[feat] ?? 1;
    const std_val = (raw - mean) / (std || 1);
    const w    = (weights.weights as any)[feat] ?? 0;
    const contrib = w * std_val;
    logit += contrib;
    contributions.push({ feature: feat, value: raw, contribution: contrib });
  }

  const probability = sigmoid(logit);

  // Risk level
  const thr = weights.risk_thresholds;
  let risk_level: RiskLevel = 'VERY_HIGH';
  for (const lvl of ['VERY_LOW','LOW','MEDIUM','HIGH','VERY_HIGH'] as RiskLevel[]) {
    if (probability <= (thr as any)[lvl]) { risk_level = lvl; break; }
  }

  const risk_score = Math.round((1 - probability) * 1000) / 10;

  // Explanation
  const prettyNames: Record<string, string> = {
    COMMEQTA: 'Capital Adequacy', LLPLOANS: 'Loan Loss Provisions',
    COSTTOINCOME: 'Cost-to-Income', ROE: 'Return on Equity',
    LIQASSTA: 'Liquidity Ratio', SIZE: 'Firm Size',
    working_capital_ratio: 'Working Capital Ratio',
    retained_earnings_ratio: 'Retained Earnings Ratio',
    ebit_ratio: 'EBIT / Assets', equity_to_debt: 'Equity / Debt',
    sales_ratio: 'Sales / Assets', altman_z: 'Altman Z-Score',
    car_ratio: 'Capital Adequacy Ratio', leverage_ratio: 'Leverage Ratio',
    lcr_proxy: 'Liquidity Coverage', debt_service_coverage: 'Debt Service Coverage',
    net_profit_margin: 'Net Profit Margin',
  };

  const explanation: FactorExplanation[] = contributions
    .sort((a, b) => Math.abs(b.contribution) - Math.abs(a.contribution))
    .slice(0, 6)
    .map(c => ({
      feature: prettyNames[c.feature] ?? c.feature,
      value: Math.round(c.value * 10000) / 10000,
      direction: c.contribution > 0.05 ? 'increases_risk'
               : c.contribution < -0.05 ? 'decreases_risk'
               : 'neutral',
      weight: Math.round(Math.abs(c.contribution) * 1000) / 1000,
    }));

  // Flags
  const flags: string[] = [];
  if (altman.zone === 'distress') flags.push('⚠️ Altman Z-Score in distress zone');
  if (altman.zone === 'grey')     flags.push('⚡ Altman Z-Score in grey zone');
  if (!basel.all_compliant) basel.violations.forEach(v => flags.push(`⚠️ Basel III: ${v}`));
  if ((input.roe ?? 0) < 0)      flags.push('⚠️ Negative ROE');
  if ((input.cost_to_income ?? 0) > 0.85) flags.push('⚠️ Very high cost-to-income ratio');

  return {
    probability: Math.round(probability * 10000) / 10000,
    risk_level,
    risk_score,
    color: RISK_COLORS[risk_level],
    altman,
    basel,
    explanation,
    flags,
  };
}

/** Human-readable summary */
export function getCompanyRiskSummary(r: CompanyRiskResult): string {
  const labels: Record<RiskLevel, string> = {
    VERY_LOW:  'Very low default risk',
    LOW:       'Low default risk',
    MEDIUM:    'Moderate default risk',
    HIGH:      'High default risk',
    VERY_HIGH: 'Very high default risk',
  };
  return `${labels[r.risk_level]} | Z-Score: ${r.altman.z_score} (${r.altman.zone}) | Safety score: ${r.risk_score}/100`;
}
