import { useState } from "react";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, AlertCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";
import type { CompanyInput } from "@/lib/risk/companyRiskScorer";
import RiskResultDisplay from "@/components/RiskResultDisplay";

export default function CompanyAssessment() {
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState<CompanyInput>({});
  const [showResults, setShowResults] = useState(false);

  const scoreCompany = trpc.risk.scoreCompany.useMutation();

  const handleInputChange = (field: keyof CompanyInput, value: string | number) => {
    setFormData((prev: CompanyInput) => ({
      ...prev,
      [field]: value === "" ? undefined : value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    scoreCompany.mutate(formData, {
      onSuccess: () => {
        setShowResults(true);
      },
    });
  };

  const handleReset = () => {
    setFormData({});
    setShowResults(false);
    scoreCompany.reset();
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="border-b border-slate-200 bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-6 py-6 flex items-center gap-4">
          <button
            onClick={() => setLocation("/")}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Company Credit Risk Assessment</h1>
            <p className="text-slate-600 text-sm mt-1">
              Evaluate enterprise credit risk using financial ratios and Basel III compliance
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-6 py-8">
        {!showResults ? (
          <Card className="p-8 border-slate-200">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Core Financial Ratios Section */}
              <div>
                <h2 className="text-lg font-semibold text-slate-900 mb-4">Core Financial Ratios</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="common_equity_ratio" className="text-slate-700 font-medium">
                      Common Equity Ratio (0-1)
                    </Label>
                    <Input
                      id="common_equity_ratio"
                      type="number"
                      min="0"
                      max="1"
                      step="0.01"
                      placeholder="0.08"
                      value={formData.common_equity_ratio ?? ""}
                      onChange={(e) => handleInputChange("common_equity_ratio", parseFloat(e.target.value) || "")}
                      className="mt-2"
                    />
                    <p className="text-xs text-slate-500 mt-1">Common Equity / Total Assets</p>
                  </div>
                  <div>
                    <Label htmlFor="roe" className="text-slate-700 font-medium">
                      Return on Equity (0-1)
                    </Label>
                    <Input
                      id="roe"
                      type="number"
                      step="0.01"
                      placeholder="0.12"
                      value={formData.roe ?? ""}
                      onChange={(e) => handleInputChange("roe", parseFloat(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="cost_to_income" className="text-slate-700 font-medium">
                      Cost to Income Ratio
                    </Label>
                    <Input
                      id="cost_to_income"
                      type="number"
                      step="0.01"
                      placeholder="0.62"
                      value={formData.cost_to_income ?? ""}
                      onChange={(e) => handleInputChange("cost_to_income", parseFloat(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="liq_assets_ratio" className="text-slate-700 font-medium">
                      Liquid Assets Ratio (0-1)
                    </Label>
                    <Input
                      id="liq_assets_ratio"
                      type="number"
                      min="0"
                      max="1"
                      step="0.01"
                      placeholder="0.20"
                      value={formData.liq_assets_ratio ?? ""}
                      onChange={(e) => handleInputChange("liq_assets_ratio", parseFloat(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                </div>
              </div>

              {/* Altman Z-Score Components */}
              <div>
                <h2 className="text-lg font-semibold text-slate-900 mb-4">Altman Z-Score Components</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="working_capital_ratio" className="text-slate-700 font-medium">
                      Working Capital Ratio (X1)
                    </Label>
                    <Input
                      id="working_capital_ratio"
                      type="number"
                      step="0.01"
                      placeholder="0.15"
                      value={formData.working_capital_ratio ?? ""}
                      onChange={(e) => handleInputChange("working_capital_ratio", parseFloat(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="retained_earnings_ratio" className="text-slate-700 font-medium">
                      Retained Earnings Ratio (X2)
                    </Label>
                    <Input
                      id="retained_earnings_ratio"
                      type="number"
                      step="0.01"
                      placeholder="0.20"
                      value={formData.retained_earnings_ratio ?? ""}
                      onChange={(e) => handleInputChange("retained_earnings_ratio", parseFloat(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="ebit_ratio" className="text-slate-700 font-medium">
                      EBIT Ratio (X3)
                    </Label>
                    <Input
                      id="ebit_ratio"
                      type="number"
                      step="0.01"
                      placeholder="0.08"
                      value={formData.ebit_ratio ?? ""}
                      onChange={(e) => handleInputChange("ebit_ratio", parseFloat(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="equity_to_debt" className="text-slate-700 font-medium">
                      Equity to Debt Ratio (X4)
                    </Label>
                    <Input
                      id="equity_to_debt"
                      type="number"
                      step="0.01"
                      placeholder="1.5"
                      value={formData.equity_to_debt ?? ""}
                      onChange={(e) => handleInputChange("equity_to_debt", parseFloat(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="sales_ratio" className="text-slate-700 font-medium">
                      Sales Ratio (X5)
                    </Label>
                    <Input
                      id="sales_ratio"
                      type="number"
                      step="0.01"
                      placeholder="1.0"
                      value={formData.sales_ratio ?? ""}
                      onChange={(e) => handleInputChange("sales_ratio", parseFloat(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                </div>
              </div>

              {/* Basel III Compliance */}
              <div>
                <h2 className="text-lg font-semibold text-slate-900 mb-4">Basel III Compliance</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <Label htmlFor="capital_adequacy_ratio" className="text-slate-700 font-medium">
                      Capital Adequacy Ratio (min: 10.5%)
                    </Label>
                    <Input
                      id="capital_adequacy_ratio"
                      type="number"
                      min="0"
                      step="0.01"
                      placeholder="0.105"
                      value={formData.capital_adequacy_ratio ?? ""}
                      onChange={(e) => handleInputChange("capital_adequacy_ratio", parseFloat(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="leverage_ratio" className="text-slate-700 font-medium">
                      Leverage Ratio (min: 3%)
                    </Label>
                    <Input
                      id="leverage_ratio"
                      type="number"
                      min="0"
                      step="0.01"
                      placeholder="0.03"
                      value={formData.leverage_ratio ?? ""}
                      onChange={(e) => handleInputChange("leverage_ratio", parseFloat(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="lcr" className="text-slate-700 font-medium">
                      Liquidity Coverage Ratio (min: 1.0)
                    </Label>
                    <Input
                      id="lcr"
                      type="number"
                      min="0"
                      step="0.01"
                      placeholder="1.0"
                      value={formData.lcr ?? ""}
                      onChange={(e) => handleInputChange("lcr", parseFloat(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                </div>
              </div>

              {/* Additional Metrics */}
              <div>
                <h2 className="text-lg font-semibold text-slate-900 mb-4">Additional Metrics</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="debt_service_coverage" className="text-slate-700 font-medium">
                      Debt Service Coverage Ratio
                    </Label>
                    <Input
                      id="debt_service_coverage"
                      type="number"
                      step="0.01"
                      placeholder="2.5"
                      value={formData.debt_service_coverage ?? ""}
                      onChange={(e) => handleInputChange("debt_service_coverage", parseFloat(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="net_profit_margin" className="text-slate-700 font-medium">
                      Net Profit Margin (0-1)
                    </Label>
                    <Input
                      id="net_profit_margin"
                      type="number"
                      step="0.01"
                      placeholder="0.15"
                      value={formData.net_profit_margin ?? ""}
                      onChange={(e) => handleInputChange("net_profit_margin", parseFloat(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                </div>
              </div>

              {/* Error Display */}
              {scoreCompany.error && (
                <div className="flex items-start gap-3 p-4 bg-red-50 border border-red-200 rounded-lg">
                  <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-red-900">Error</p>
                    <p className="text-sm text-red-700 mt-1">
                      {scoreCompany.error.message || "An error occurred while scoring"}
                    </p>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-4 pt-4">
                <Button
                  type="submit"
                  disabled={scoreCompany.isPending}
                  className="flex-1"
                >
                  {scoreCompany.isPending ? "Assessing..." : "Assess Risk"}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleReset}
                  className="flex-1"
                >
                  Reset Form
                </Button>
              </div>
            </form>
          </Card>
        ) : scoreCompany.data ? (
          <div className="space-y-6">
            <RiskResultDisplay result={scoreCompany.data} />
            <div className="flex gap-4">
              <Button
                onClick={handleReset}
                variant="outline"
                className="flex-1"
              >
                New Assessment
              </Button>
              <Button
                onClick={() => setLocation("/")}
                variant="outline"
                className="flex-1"
              >
                Back to Hub
              </Button>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
