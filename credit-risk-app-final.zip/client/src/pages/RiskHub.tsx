import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, Building2, BarChart3 } from "lucide-react";

export default function RiskHub() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <div className="border-b border-slate-200 bg-white shadow-sm">
        <div className="max-w-6xl mx-auto px-6 py-8">
          <h1 className="text-3xl font-bold text-slate-900">Credit Risk Assessment</h1>
          <p className="text-slate-600 mt-2">
            Evaluate credit risk for individuals and companies using advanced ML models
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Individual Assessment Card */}
          <Card className="p-8 hover:shadow-lg transition-shadow cursor-pointer border-slate-200"
            onClick={() => setLocation("/risk/individual")}>
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Users className="w-8 h-8 text-blue-600" />
              </div>
              <h2 className="text-xl font-semibold text-slate-900 mb-2">Individual Assessment</h2>
              <p className="text-slate-600 text-sm mb-6">
                Evaluate credit risk for individuals based on income, credit history, and financial behavior
              </p>
              <Button variant="default" className="w-full">
                Start Assessment
              </Button>
            </div>
          </Card>

          {/* Company Assessment Card */}
          <Card className="p-8 hover:shadow-lg transition-shadow cursor-pointer border-slate-200"
            onClick={() => setLocation("/risk/company")}>
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 bg-emerald-100 rounded-lg flex items-center justify-center mb-4">
                <Building2 className="w-8 h-8 text-emerald-600" />
              </div>
              <h2 className="text-xl font-semibold text-slate-900 mb-2">Company Assessment</h2>
              <p className="text-slate-600 text-sm mb-6">
                Assess enterprise credit risk using financial ratios, Altman Z-Score, and Basel III compliance
              </p>
              <Button variant="default" className="w-full">
                Start Assessment
              </Button>
            </div>
          </Card>

          {/* Dashboard Card */}
          <Card className="p-8 hover:shadow-lg transition-shadow cursor-pointer border-slate-200"
            onClick={() => setLocation("/dashboard")}>
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <BarChart3 className="w-8 h-8 text-purple-600" />
              </div>
              <h2 className="text-xl font-semibold text-slate-900 mb-2">Analytics Dashboard</h2>
              <p className="text-slate-600 text-sm mb-6">
                View comprehensive analytics and historical assessment data
              </p>
              <Button variant="default" className="w-full">
                View Dashboard
              </Button>
            </div>
          </Card>
        </div>

        {/* Info Section */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white rounded-lg border border-slate-200 p-6">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Individual Model</h3>
            <ul className="space-y-2 text-sm text-slate-600">
              <li className="flex items-start">
                <span className="text-blue-600 mr-2">•</span>
                <span>AUC Score: 0.866 (150K training samples)</span>
              </li>
              <li className="flex items-start">
                <span className="text-blue-600 mr-2">•</span>
                <span>Analyzes credit utilization, payment history, income</span>
              </li>
              <li className="flex items-start">
                <span className="text-blue-600 mr-2">•</span>
                <span>Provides risk level from VERY_LOW to VERY_HIGH</span>
              </li>
            </ul>
          </div>

          <div className="bg-white rounded-lg border border-slate-200 p-6">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Company Model</h3>
            <ul className="space-y-2 text-sm text-slate-600">
              <li className="flex items-start">
                <span className="text-emerald-600 mr-2">•</span>
                <span>AUC Score: 0.974 (197 S&P firms)</span>
              </li>
              <li className="flex items-start">
                <span className="text-emerald-600 mr-2">•</span>
                <span>Includes Altman Z-Score and Basel III compliance checks</span>
              </li>
              <li className="flex items-start">
                <span className="text-emerald-600 mr-2">•</span>
                <span>Comprehensive financial ratio analysis</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
