import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { assessRisk } from "../src/lib/risk/riskAssessment";
import { createAssessment, getAssessmentStats, getAssessmentsByUserId } from "./db";
import { TRPCError } from "@trpc/server";

// Zod schemas for validation
const IndividualSchema = z.object({
  age: z.number().min(18).max(120).optional(),
  monthly_income: z.number().min(0).optional(),
  credit_utilization_ratio: z.number().min(0).max(1).optional(),
  debt_to_income_ratio: z.number().min(0).optional(),
  open_credit_lines: z.number().int().min(0).optional(),
  times_90_days_late: z.number().int().min(0).optional(),
  times_60_89_days_late: z.number().int().min(0).optional(),
  times_30_59_days_late: z.number().int().min(0).optional(),
  real_estate_loans: z.number().int().min(0).optional(),
  number_of_dependents: z.number().int().min(0).optional(),
});

const CompanySchema = z.object({
  common_equity_ratio: z.number().optional(),
  loan_loss_provisions: z.number().optional(),
  cost_to_income: z.number().optional(),
  roe: z.number().optional(),
  liq_assets_ratio: z.number().optional(),
  size_log_assets: z.number().optional(),
  working_capital_ratio: z.number().optional(),
  retained_earnings_ratio: z.number().optional(),
  ebit_ratio: z.number().optional(),
  equity_to_debt: z.number().optional(),
  sales_ratio: z.number().optional(),
  capital_adequacy_ratio: z.number().optional(),
  leverage_ratio: z.number().optional(),
  lcr: z.number().optional(),
  debt_service_coverage: z.number().optional(),
  net_profit_margin: z.number().optional(),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  risk: router({
    scoreIndividual: publicProcedure
      .input(IndividualSchema)
      .mutation(async ({ input, ctx }) => {
        const result = assessRisk("individual", input);
        if (ctx.user) {
          await createAssessment({
            userId: ctx.user.id,
            type: "individual",
            inputData: JSON.stringify(input),
            resultData: JSON.stringify(result),
            score: result.score,
            riskLevel: result.risk_level,
          });
        }
        return result;
      }),

    scoreCompany: publicProcedure
      .input(CompanySchema)
      .mutation(async ({ input, ctx }) => {
        const result = assessRisk("company", input);
        if (ctx.user) {
          await createAssessment({
            userId: ctx.user.id,
            type: "company",
            inputData: JSON.stringify(input),
            resultData: JSON.stringify(result),
            score: result.score,
            riskLevel: result.risk_level,
          });
        }
        return result;
      }),

    getStats: publicProcedure.query(async ({ ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }
      return getAssessmentStats(ctx.user.id);
    }),

    getHistory: publicProcedure.query(async ({ ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }
      return getAssessmentsByUserId(ctx.user.id);
    }),
  }),
});

export type AppRouter = typeof appRouter;
