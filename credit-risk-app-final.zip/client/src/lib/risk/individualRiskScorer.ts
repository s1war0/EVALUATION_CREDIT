/**
 * individualRiskScorer.ts
 * ========================
 * Pure TypeScript risk scorer — works in Node or browser.
 * No Python server needed. Uses the trained LR weights from individual_scoring_weights.json
 *
 * Usage:
 *   import { scoreIndividual } from './individualRiskScorer';
 *   const result = scoreIndividual({ age: 35, monthly_income: 5000, ... });
 */

import weights from './individual_scoring_weights.json';

// ── Types ──────────────────────────────────────────────────────────────────

export interface IndividualClientInput {
  /** Credit utilization ratio (0–1). E.g. 0.3 = 30% used */
  credit_utilization_ratio?: number;
  age?: number;
  /** Total debt / monthly income ratio */
  debt_to_income_ratio?: number;
  /** Gross monthly income in USD */
  monthly_income?: number;
  /** Number of open credit lines + loans */
  open_credit_lines?: number;
  /** Times 90+ days late on payment */
  times_90_days_late?: number;
  /** Number of real estate loans or lines */
  real_estate_loans?: number;
  /** Times 60–89 days late */
  times_60_89_days_late?: number;
  /** Times 30–59 days late */
  times_30_59_days_late?: number;
  number_of_dependents?: number;
}

export type RiskLevel = 'VERY_LOW' | 'LOW' | 'MEDIUM' | 'HIGH' | 'VERY_HIGH';

export interface RiskResult {
  /** Default probability (0–1) */
  probability: number;
  /** Risk level label */
  risk_level: RiskLevel;
  /** 0–100 safety score (higher = safer) */
  risk_score: number;
  /** Hex color for UI display */
  color: string;
  /** Top contributing factors */
  explanation: FactorExplanation[];
}

export interface FactorExplanation {
  feature: string;
  value: number;
  direction: 'increases_risk' | 'decreases_risk' | 'neutral';
  weight: number;
}

// ── Constants ──────────────────────────────────────────────────────────────

const RISK_COLORS: Record<RiskLevel, string> = {
  VERY_LOW:  '#22c55e',
  LOW:       '#84cc16',
  MEDIUM:    '#f59e0b',
  HIGH:      '#f97316',
  VERY_HIGH: '#ef4444',
};

const FEATURE_ORDER = weights.feature_order;

// Reverse mapping: app name → internal feature name
const APP_TO_INTERNAL: Record<string, string> = Object.fromEntries(
  Object.entries(weights.feature_mapping).map(([k, v]) => [v, k])
);

// ── Core math ──────────────────────────────────────────────────────────────

function sigmoid(x: number): number {
  return 1 / (1 + Math.exp(-x));
}

function getFeatureValue(input: IndividualClientInput, internalName: string): number {
  const appName = weights.feature_mapping[internalName as keyof typeof weights.feature_mapping];
  const raw = input[appName as keyof IndividualClientInput];
  // Fallback to imputer median if missing
  const median = weights.imputer_medians[internalName as keyof typeof weights.imputer_medians] ?? 0;
  return raw != null ? Number(raw) : median;
}

function standardize(value: number, internalName: string): number {
  const mean = weights.scaler_mean[internalName as keyof typeof weights.scaler_mean] ?? 0;
  const std  = weights.scaler_std[internalName as keyof typeof weights.scaler_std] ?? 1;
  return (value - mean) / (std || 1);
}

// ── Public API ─────────────────────────────────────────────────────────────

/**
 * Score an individual client for default risk.
 * All fields are optional — missing values are imputed automatically.
 */
export function scoreIndividual(input: IndividualClientInput): RiskResult {
  let logit = weights.intercept;
  const contributions: { feature: string; value: number; contribution: number; weight: number }[] = [];

  for (const feat of FEATURE_ORDER) {
    const raw   = getFeatureValue(input, feat);
    const std   = standardize(raw, feat);
    const w     = weights.weights[feat as keyof typeof weights.weights] ?? 0;
    const contrib = w * std;
    logit += contrib;
    contributions.push({ feature: feat, value: raw, contribution: contrib, weight: w });
  }

  const probability = sigmoid(logit);

  // Determine risk level
  const thresholds = weights.risk_thresholds;
  let risk_level: RiskLevel = 'VERY_HIGH';
  for (const lvl of ['VERY_LOW', 'LOW', 'MEDIUM', 'HIGH', 'VERY_HIGH'] as RiskLevel[]) {
    if (probability <= thresholds[lvl as keyof typeof thresholds]) {
      risk_level = lvl;
      break;
    }
  }

  const risk_score = Math.round((1 - probability) * 100 * 10) / 10;

  // Build explanation (top 5 by absolute contribution)
  const appNameMap = weights.feature_mapping;
  const explanation: FactorExplanation[] = contributions
    .sort((a, b) => Math.abs(b.contribution) - Math.abs(a.contribution))
    .slice(0, 5)
    .map(c => ({
      feature: appNameMap[c.feature as keyof typeof appNameMap] ?? c.feature,
      value: Math.round(c.value * 1000) / 1000,
      direction: c.contribution > 0.01 ? 'increases_risk'
               : c.contribution < -0.01 ? 'decreases_risk'
               : 'neutral',
      weight: Math.round(Math.abs(c.contribution) * 1000) / 1000,
    }));

  return {
    probability: Math.round(probability * 10000) / 10000,
    risk_level,
    risk_score,
    color: RISK_COLORS[risk_level],
    explanation,
  };
}

/**
 * Get a human-readable risk summary.
 */
export function getRiskSummary(result: RiskResult): string {
  const pct = Math.round(result.probability * 100);
  const labels: Record<RiskLevel, string> = {
    VERY_LOW:  'Very low risk of default',
    LOW:       'Low risk of default',
    MEDIUM:    'Moderate risk of default',
    HIGH:      'High risk of default',
    VERY_HIGH: 'Very high risk of default',
  };
  return `${labels[result.risk_level]} (${pct}% default probability, safety score: ${result.risk_score}/100)`;
}
