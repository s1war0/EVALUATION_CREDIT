import { AssessmentResult } from "@/lib/risk/riskAssessment";
import { Card } from "@/components/ui/card";
import { AlertCircle, TrendingDown, TrendingUp } from "lucide-react";

interface RiskResultDisplayProps {
  result: AssessmentResult;
}

export default function RiskResultDisplay({ result }: RiskResultDisplayProps) {
  if (result.type === "individual") {
    const { data } = result;
    const riskLevelColors: Record<string, string> = {
      VERY_LOW: "bg-green-50 border-green-200",
      LOW: "bg-lime-50 border-lime-200",
      MEDIUM: "bg-amber-50 border-amber-200",
      HIGH: "bg-orange-50 border-orange-200",
      VERY_HIGH: "bg-red-50 border-red-200",
    };

    const riskLevelTextColors: Record<string, string> = {
      VERY_LOW: "text-green-900",
      LOW: "text-lime-900",
      MEDIUM: "text-amber-900",
      HIGH: "text-orange-900",
      VERY_HIGH: "text-red-900",
    };

    return (
      <div className="space-y-6">
        {/* Main Score Card */}
        <Card className={`p-8 border-2 ${riskLevelColors[data.risk_level]}`}>
          <div className="flex items-start justify-between mb-6">
            <div>
              <h2 className="text-lg font-semibold text-slate-900 mb-2">Risk Assessment Result</h2>
              <p className="text-slate-600">Individual Credit Risk Evaluation</p>
            </div>
            <div
              className="w-12 h-12 rounded-full flex items-center justify-center"
              style={{ backgroundColor: data.color + "20", borderColor: data.color, borderWidth: "2px" }}
            >
              <div
                className="w-8 h-8 rounded-full"
                style={{ backgroundColor: data.color }}
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-sm text-slate-600 font-medium">Risk Level</p>
              <p className={`text-2xl font-bold mt-2 ${riskLevelTextColors[data.risk_level]}`}>
                {data.risk_level.replace(/_/g, " ")}
              </p>
            </div>
            <div>
              <p className="text-sm text-slate-600 font-medium">Risk Score</p>
              <p className="text-2xl font-bold text-slate-900 mt-2">{data.risk_score}/100</p>
            </div>
            <div>
              <p className="text-sm text-slate-600 font-medium">Default Probability</p>
              <p className="text-2xl font-bold text-slate-900 mt-2">
                {(data.probability * 100).toFixed(2)}%
              </p>
            </div>
          </div>
        </Card>

        {/* Risk Score Gauge */}
        <Card className="p-6 border-slate-200">
          <h3 className="text-lg font-semibold text-slate-900 mb-4">Risk Score Gauge</h3>
          <div className="space-y-2">
            <div className="flex justify-between text-sm text-slate-600 mb-2">
              <span>Lower Risk</span>
              <span>Higher Risk</span>
            </div>
            <div className="w-full h-3 bg-gradient-to-r from-green-500 via-amber-500 to-red-500 rounded-full overflow-hidden">
              <div
                className="h-full bg-slate-900 w-1 rounded-full"
                style={{ marginLeft: `${data.risk_score}%` }}
              />
            </div>
            <div className="flex justify-between text-xs text-slate-500 mt-2">
              <span>0</span>
              <span>50</span>
              <span>100</span>
            </div>
          </div>
        </Card>

        {/* Contributing Factors */}
        {data.explanation && data.explanation.length > 0 && (
          <Card className="p-6 border-slate-200">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Contributing Factors</h3>
            <div className="space-y-3">
              {data.explanation.slice(0, 5).map((factor: any, idx: number) => (
                <div key={idx} className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg">
                  <div className="flex-shrink-0 mt-1">
                    {factor.direction === "increases_risk" ? (
                      <TrendingUp className="w-4 h-4 text-red-600" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-green-600" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-900">{factor.feature}</p>
                    <p className="text-xs text-slate-600 mt-1">
                      Value: {typeof factor.value === "number" ? factor.value.toFixed(3) : factor.value}
                      {" • "}
                      Weight: {(factor.weight * 100).toFixed(1)}%
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Summary */}
        <Card className="p-6 border-slate-200 bg-slate-50">
          <h3 className="text-lg font-semibold text-slate-900 mb-3">Assessment Summary</h3>
          <p className="text-slate-700 leading-relaxed">{result.summary}</p>
        </Card>
      </div>
    );
  }

  // Company result display
  if (result.type === "company") {
    const { data } = result;
    const riskLevelColors: Record<string, string> = {
      VERY_LOW: "bg-green-50 border-green-200",
      LOW: "bg-lime-50 border-lime-200",
      MEDIUM: "bg-amber-50 border-amber-200",
      HIGH: "bg-orange-50 border-orange-200",
      VERY_HIGH: "bg-red-50 border-red-200",
    };

    const riskLevelTextColors: Record<string, string> = {
      VERY_LOW: "text-green-900",
      LOW: "text-lime-900",
      MEDIUM: "text-amber-900",
      HIGH: "text-orange-900",
      VERY_HIGH: "text-red-900",
    };

    return (
      <div className="space-y-6">
        {/* Main Score Card */}
        <Card className={`p-8 border-2 ${riskLevelColors[data.risk_level]}`}>
          <div className="flex items-start justify-between mb-6">
            <div>
              <h2 className="text-lg font-semibold text-slate-900 mb-2">Risk Assessment Result</h2>
              <p className="text-slate-600">Company Credit Risk Evaluation</p>
            </div>
            <div
              className="w-12 h-12 rounded-full flex items-center justify-center"
              style={{ backgroundColor: data.color + "20", borderColor: data.color, borderWidth: "2px" }}
            >
              <div
                className="w-8 h-8 rounded-full"
                style={{ backgroundColor: data.color }}
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-sm text-slate-600 font-medium">Risk Level</p>
              <p className={`text-2xl font-bold mt-2 ${riskLevelTextColors[data.risk_level]}`}>
                {data.risk_level.replace(/_/g, " ")}
              </p>
            </div>
            <div>
              <p className="text-sm text-slate-600 font-medium">Risk Score</p>
              <p className="text-2xl font-bold text-slate-900 mt-2">{data.risk_score}/100</p>
            </div>
            <div>
              <p className="text-sm text-slate-600 font-medium">Default Probability</p>
              <p className="text-2xl font-bold text-slate-900 mt-2">
                {(data.probability * 100).toFixed(2)}%
              </p>
            </div>
          </div>
        </Card>

        {/* Altman Z-Score */}
        <Card className="p-6 border-slate-200">
          <h3 className="text-lg font-semibold text-slate-900 mb-4">Altman Z-Score Analysis</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <p className="text-sm text-slate-600 font-medium mb-2">Z-Score Value</p>
              <p className="text-3xl font-bold text-slate-900">{data.altman.z_score.toFixed(2)}</p>
              <p className="text-sm text-slate-600 mt-2">{data.altman.zone_label}</p>
            </div>
            <div className="space-y-2">
              {data.altman.components.map((comp: any, idx: number) => (
                <div key={idx} className="flex justify-between text-sm">
                  <span className="text-slate-700">{comp.name}</span>
                  <span className="font-medium text-slate-900">{comp.contribution.toFixed(3)}</span>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Basel III Compliance */}
        <Card className="p-6 border-slate-200">
          <h3 className="text-lg font-semibold text-slate-900 mb-4">Basel III Compliance</h3>
          <div className="space-y-2">
            {data.basel.violations.length === 0 ? (
              <div className="p-3 bg-green-50 border border-green-200 rounded-lg flex items-start gap-2">
                <AlertCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-green-900">All Basel III requirements met</p>
              </div>
            ) : (
              data.basel.violations.map((violation: any, idx: number) => (
                <div key={idx} className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2">
                  <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-red-900">{violation}</p>
                </div>
              ))
            )}
          </div>
        </Card>

        {/* Contributing Factors */}
        {data.explanation && data.explanation.length > 0 && (
          <Card className="p-6 border-slate-200">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Contributing Factors</h3>
            <div className="space-y-3">
              {data.explanation.slice(0, 5).map((factor: any, idx: number) => (
                <div key={idx} className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg">
                  <div className="flex-shrink-0 mt-1">
                    {factor.direction === "increases_risk" ? (
                      <TrendingUp className="w-4 h-4 text-red-600" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-green-600" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-900">{factor.feature}</p>
                    <p className="text-xs text-slate-600 mt-1">
                      Value: {typeof factor.value === "number" ? factor.value.toFixed(3) : factor.value}
                      {" • "}
                      Weight: {(factor.weight * 100).toFixed(1)}%
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Summary */}
        <Card className="p-6 border-slate-200 bg-slate-50">
          <h3 className="text-lg font-semibold text-slate-900 mb-3">Assessment Summary</h3>
          <p className="text-slate-700 leading-relaxed">{result.summary}</p>
        </Card>
      </div>
    );
  }

  return null;
}
