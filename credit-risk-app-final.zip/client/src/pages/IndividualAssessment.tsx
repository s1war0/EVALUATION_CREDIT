import { useState } from "react";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, AlertCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";
import type { IndividualClientInput } from "@/lib/risk/individualRiskScorer";
import RiskResultDisplay from "@/components/RiskResultDisplay";

export default function IndividualAssessment() {
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState<IndividualClientInput>({});
  const [showResults, setShowResults] = useState(false);

  const scoreIndividual = trpc.risk.scoreIndividual.useMutation();

  const handleInputChange = (field: keyof IndividualClientInput, value: string | number) => {
    setFormData((prev: IndividualClientInput) => ({
      ...prev,
      [field]: value === "" ? undefined : value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    scoreIndividual.mutate(formData, {
      onSuccess: () => {
        setShowResults(true);
      },
    });
  };

  const handleReset = () => {
    setFormData({});
    setShowResults(false);
    scoreIndividual.reset();
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="border-b border-slate-200 bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-6 py-6 flex items-center gap-4">
          <button
            onClick={() => setLocation("/")}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Individual Credit Risk Assessment</h1>
            <p className="text-slate-600 text-sm mt-1">
              Evaluate credit risk based on personal financial information
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-6 py-8">
        {!showResults ? (
          <Card className="p-8 border-slate-200">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Personal Information Section */}
              <div>
                <h2 className="text-lg font-semibold text-slate-900 mb-4">Personal Information</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="age" className="text-slate-700 font-medium">
                      Age
                    </Label>
                    <Input
                      id="age"
                      type="number"
                      min="18"
                      max="120"
                      placeholder="Enter your age"
                      value={formData.age ?? ""}
                      onChange={(e) => handleInputChange("age", parseInt(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="monthly_income" className="text-slate-700 font-medium">
                      Monthly Income (USD)
                    </Label>
                    <Input
                      id="monthly_income"
                      type="number"
                      min="0"
                      placeholder="Enter monthly income"
                      value={formData.monthly_income ?? ""}
                      onChange={(e) => handleInputChange("monthly_income", parseFloat(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                </div>
              </div>

              {/* Credit Information Section */}
              <div>
                <h2 className="text-lg font-semibold text-slate-900 mb-4">Credit Information</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="credit_utilization" className="text-slate-700 font-medium">
                      Credit Utilization Ratio (0-1)
                    </Label>
                    <Input
                      id="credit_utilization"
                      type="number"
                      min="0"
                      max="1"
                      step="0.01"
                      placeholder="0.45"
                      value={formData.credit_utilization_ratio ?? ""}
                      onChange={(e) => handleInputChange("credit_utilization_ratio", parseFloat(e.target.value) || "")}
                      className="mt-2"
                    />
                    <p className="text-xs text-slate-500 mt-1">Example: 0.45 = 45% of available credit used</p>
                  </div>
                  <div>
                    <Label htmlFor="debt_to_income" className="text-slate-700 font-medium">
                      Debt to Income Ratio
                    </Label>
                    <Input
                      id="debt_to_income"
                      type="number"
                      min="0"
                      step="0.01"
                      placeholder="0.30"
                      value={formData.debt_to_income_ratio ?? ""}
                      onChange={(e) => handleInputChange("debt_to_income_ratio", parseFloat(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                </div>
              </div>

              {/* Payment History Section */}
              <div>
                <h2 className="text-lg font-semibold text-slate-900 mb-4">Payment History</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <Label htmlFor="times_30_59" className="text-slate-700 font-medium">
                      Times 30-59 Days Late
                    </Label>
                    <Input
                      id="times_30_59"
                      type="number"
                      min="0"
                      placeholder="0"
                      value={formData.times_30_59_days_late ?? ""}
                      onChange={(e) => handleInputChange("times_30_59_days_late", parseInt(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="times_60_89" className="text-slate-700 font-medium">
                      Times 60-89 Days Late
                    </Label>
                    <Input
                      id="times_60_89"
                      type="number"
                      min="0"
                      placeholder="0"
                      value={formData.times_60_89_days_late ?? ""}
                      onChange={(e) => handleInputChange("times_60_89_days_late", parseInt(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="times_90" className="text-slate-700 font-medium">
                      Times 90+ Days Late
                    </Label>
                    <Input
                      id="times_90"
                      type="number"
                      min="0"
                      placeholder="0"
                      value={formData.times_90_days_late ?? ""}
                      onChange={(e) => handleInputChange("times_90_days_late", parseInt(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                </div>
              </div>

              {/* Additional Information Section */}
              <div>
                <h2 className="text-lg font-semibold text-slate-900 mb-4">Additional Information</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="open_credit_lines" className="text-slate-700 font-medium">
                      Open Credit Lines
                    </Label>
                    <Input
                      id="open_credit_lines"
                      type="number"
                      min="0"
                      placeholder="0"
                      value={formData.open_credit_lines ?? ""}
                      onChange={(e) => handleInputChange("open_credit_lines", parseInt(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="real_estate_loans" className="text-slate-700 font-medium">
                      Real Estate Loans
                    </Label>
                    <Input
                      id="real_estate_loans"
                      type="number"
                      min="0"
                      placeholder="0"
                      value={formData.real_estate_loans ?? ""}
                      onChange={(e) => handleInputChange("real_estate_loans", parseInt(e.target.value) || "")}
                      className="mt-2"
                    />
                  </div>
                </div>
              </div>

              {/* Error Display */}
              {scoreIndividual.error && (
                <div className="flex items-start gap-3 p-4 bg-red-50 border border-red-200 rounded-lg">
                  <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-red-900">Error</p>
                    <p className="text-sm text-red-700 mt-1">
                      {scoreIndividual.error.message || "An error occurred while scoring"}
                    </p>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-4 pt-4">
                <Button
                  type="submit"
                  disabled={scoreIndividual.isPending}
                  className="flex-1"
                >
                  {scoreIndividual.isPending ? "Assessing..." : "Assess Risk"}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleReset}
                  className="flex-1"
                >
                  Reset Form
                </Button>
              </div>
            </form>
          </Card>
        ) : scoreIndividual.data ? (
          <div className="space-y-6">
            <RiskResultDisplay result={scoreIndividual.data} />
            <div className="flex gap-4">
              <Button
                onClick={handleReset}
                variant="outline"
                className="flex-1"
              >
                New Assessment
              </Button>
              <Button
                onClick={() => setLocation("/")}
                variant="outline"
                className="flex-1"
              >
                Back to Hub
              </Button>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
