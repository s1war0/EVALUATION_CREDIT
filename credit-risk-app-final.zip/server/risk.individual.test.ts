import { describe, expect, it } from "vitest";
import { scoreIndividual, getRiskSummary } from "../src/lib/risk/individualRiskScorer";
import type { IndividualClientInput } from "../src/lib/risk/individualRiskScorer";

describe("Individual Risk Scorer", () => {
  it("should score a low-risk individual", () => {
    const input: IndividualClientInput = {
      age: 35,
      monthly_income: 5000,
      credit_utilization_ratio: 0.2,
      debt_to_income_ratio: 0.15,
      times_30_59_days_late: 0,
      times_60_89_days_late: 0,
      times_90_days_late: 0,
      open_credit_lines: 3,
      real_estate_loans: 1,
    };

    const result = scoreIndividual(input);

    expect(result).toBeDefined();
    expect(result.probability).toBeGreaterThanOrEqual(0);
    expect(result.probability).toBeLessThanOrEqual(1);
    expect(result.risk_score).toBeGreaterThanOrEqual(0);
    expect(result.risk_score).toBeLessThanOrEqual(100);
    expect(result.risk_level).toMatch(/VERY_LOW|LOW|MEDIUM|HIGH|VERY_HIGH/);
    expect(result.color).toMatch(/^#[0-9A-Fa-f]{6}$/);
    expect(result.explanation).toBeDefined();
    expect(Array.isArray(result.explanation)).toBe(true);
  });

  it("should score a high-risk individual", () => {
    const input: IndividualClientInput = {
      age: 25,
      monthly_income: 1500,
      credit_utilization_ratio: 0.95,
      debt_to_income_ratio: 0.85,
      times_30_59_days_late: 3,
      times_60_89_days_late: 2,
      times_90_days_late: 1,
      open_credit_lines: 8,
    };

    const result = scoreIndividual(input);

    expect(result).toBeDefined();
    expect(result.risk_score).toBeDefined();
    expect(result.risk_level).toMatch(/VERY_LOW|LOW|MEDIUM|HIGH|VERY_HIGH/);
  });

  it("should handle missing fields with imputation", () => {
    const input: IndividualClientInput = {
      age: 40,
      monthly_income: 4000,
    };

    const result = scoreIndividual(input);

    expect(result).toBeDefined();
    expect(result.probability).toBeGreaterThanOrEqual(0);
    expect(result.probability).toBeLessThanOrEqual(1);
    expect(result.risk_score).toBeGreaterThanOrEqual(0);
    expect(result.risk_score).toBeLessThanOrEqual(100);
  });

  it("should generate a risk summary", () => {
    const input: IndividualClientInput = {
      age: 35,
      monthly_income: 5000,
      credit_utilization_ratio: 0.3,
    };

    const result = scoreIndividual(input);
    const summary = getRiskSummary(result);

    expect(summary).toBeDefined();
    expect(typeof summary).toBe("string");
    expect(summary.length).toBeGreaterThan(0);
  });

  it("should provide explanation factors", () => {
    const input: IndividualClientInput = {
      age: 35,
      monthly_income: 5000,
      credit_utilization_ratio: 0.45,
      debt_to_income_ratio: 0.30,
      times_90_days_late: 1,
    };

    const result = scoreIndividual(input);

    expect(result.explanation.length).toBeGreaterThan(0);
    result.explanation.forEach((factor) => {
      expect(factor.feature).toBeDefined();
      expect(typeof factor.feature).toBe("string");
      expect(factor.value).toBeDefined();
      expect(typeof factor.value).toBe("number");
      expect(factor.direction).toMatch(/increases_risk|decreases_risk|neutral/);
      expect(factor.weight).toBeDefined();
      expect(typeof factor.weight).toBe("number");
    });
  });
});
