import { describe, expect, it } from "vitest";
import { scoreCompany, computeAltmanZ, computeBaselRatios } from "../src/lib/risk/companyRiskScorer";
import type { CompanyInput } from "../src/lib/risk/companyRiskScorer";

describe("Company Risk Scorer", () => {
  it("should score a low-risk company", () => {
    const input: CompanyInput = {
      common_equity_ratio: 0.12,
      roe: 0.15,
      cost_to_income: 0.50,
      liq_assets_ratio: 0.30,
      working_capital_ratio: 0.20,
      retained_earnings_ratio: 0.25,
      ebit_ratio: 0.12,
      equity_to_debt: 2.0,
      sales_ratio: 1.2,
      capital_adequacy_ratio: 0.15,
      leverage_ratio: 0.05,
      lcr: 1.5,
    };

    const result = scoreCompany(input);

    expect(result).toBeDefined();
    expect(result.probability).toBeGreaterThanOrEqual(0);
    expect(result.probability).toBeLessThanOrEqual(1);
    expect(result.risk_score).toBeGreaterThanOrEqual(0);
    expect(result.risk_score).toBeLessThanOrEqual(100);
    expect(result.risk_level).toMatch(/VERY_LOW|LOW|MEDIUM|HIGH|VERY_HIGH/);
    expect(result.color).toMatch(/^#[0-9A-Fa-f]{6}$/);
  });

  it("should compute Altman Z-Score correctly", () => {
    const input: CompanyInput = {
      working_capital_ratio: 0.15,
      retained_earnings_ratio: 0.20,
      ebit_ratio: 0.08,
      equity_to_debt: 1.5,
      sales_ratio: 1.0,
    };

    const altman = computeAltmanZ(input);

    expect(altman).toBeDefined();
    expect(altman.z_score).toBeDefined();
    expect(typeof altman.z_score).toBe("number");
    expect(altman.zone).toMatch(/safe|grey|distress/);
    expect(altman.zone_label).toBeDefined();
    expect(altman.color).toMatch(/^#[0-9A-Fa-f]{6}$/);
    expect(altman.components).toBeDefined();
    expect(Array.isArray(altman.components)).toBe(true);
    expect(altman.components.length).toBe(5);
  });

  it("should validate Basel III compliance", () => {
    const input: CompanyInput = {
      capital_adequacy_ratio: 0.15,
      leverage_ratio: 0.05,
      lcr: 1.5,
    };

    const basel = computeBaselRatios(input);

    expect(basel).toBeDefined();
    expect(typeof basel.car_ok).toBe("boolean");
    expect(typeof basel.leverage_ok).toBe("boolean");
    expect(typeof basel.lcr_ok).toBe("boolean");
    expect(typeof basel.all_compliant).toBe("boolean");
    expect(Array.isArray(basel.violations)).toBe(true);
  });

  it("should detect Basel III violations", () => {
    const input: CompanyInput = {
      capital_adequacy_ratio: 0.08, // Below 10.5%
      leverage_ratio: 0.02, // Below 3%
      lcr: 0.8, // Below 1.0
    };

    const basel = computeBaselRatios(input);

    expect(basel.car_ok).toBe(false);
    expect(basel.leverage_ok).toBe(false);
    expect(basel.lcr_ok).toBe(false);
    expect(basel.all_compliant).toBe(false);
    expect(basel.violations.length).toBeGreaterThan(0);
  });

  it("should handle missing fields with defaults", () => {
    const input: CompanyInput = {
      roe: 0.12,
      cost_to_income: 0.60,
    };

    const result = scoreCompany(input);

    expect(result).toBeDefined();
    expect(result.probability).toBeGreaterThanOrEqual(0);
    expect(result.probability).toBeLessThanOrEqual(1);
    expect(result.risk_score).toBeGreaterThanOrEqual(0);
    expect(result.risk_score).toBeLessThanOrEqual(100);
  });

  it("should provide explanation factors", () => {
    const input: CompanyInput = {
      common_equity_ratio: 0.10,
      roe: 0.12,
      cost_to_income: 0.55,
      liq_assets_ratio: 0.25,
    };

    const result = scoreCompany(input);

    expect(result.explanation).toBeDefined();
    expect(Array.isArray(result.explanation)).toBe(true);
    result.explanation.forEach((factor) => {
      expect(factor.feature).toBeDefined();
      expect(typeof factor.feature).toBe("string");
      expect(factor.value).toBeDefined();
      expect(typeof factor.value).toBe("number");
      expect(factor.direction).toMatch(/increases_risk|decreases_risk|neutral/);
      expect(factor.weight).toBeDefined();
      expect(typeof factor.weight).toBe("number");
    });
  });

  it("should include Altman and Basel results in company risk result", () => {
    const input: CompanyInput = {
      working_capital_ratio: 0.15,
      retained_earnings_ratio: 0.20,
      ebit_ratio: 0.08,
      equity_to_debt: 1.5,
      sales_ratio: 1.0,
      capital_adequacy_ratio: 0.15,
      leverage_ratio: 0.05,
      lcr: 1.5,
    };

    const result = scoreCompany(input);

    expect(result.altman).toBeDefined();
    expect(result.altman.z_score).toBeDefined();
    expect(result.altman.zone).toBeDefined();
    expect(result.basel).toBeDefined();
    expect(result.basel.all_compliant).toBeDefined();
  });
});
