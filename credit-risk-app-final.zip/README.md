# Credit Risk Assessment Application

Une plateforme web professionnelle pour évaluer le risque de crédit des particuliers et des entreprises, utilisant des modèles de machine learning et des analyses financières avancées.

## Caractéristiques

- **Scoring Individuel** : Évaluation basée sur 10 facteurs clés (revenu, historique de paiement, utilisation du crédit, etc.)
- **Scoring Entreprise** : Analyse complète avec 16 métriques financières
- **Analyses Avancées** :
  - Z-Score d'Altman pour évaluer la santé financière
  - Conformité Basel III pour les ratios de capital et liquidité
- **Tableau de Bord Analytique** : Visualisation des tendances et historique complet
- **Persistance des Données** : Toutes les évaluations sont sauvegardées en base de données
- **Authentification Sécurisée** : Intégration OAuth Manus

## Stack Technologique

- **Frontend** : React 19 + TypeScript + Vite
- **Backend** : Express + tRPC
- **Base de Données** : MySQL + Drizzle ORM
- **UI** : Shadcn/ui + TailwindCSS
- **Graphiques** : Recharts
- **Tests** : Vitest (13 tests, tous passants)

## Installation Rapide

```bash
# Cloner et installer
git clone <repository-url>
cd credit-risk-app
pnpm install

# Configurer l'environnement
cp .env.example .env.local
# Éditer .env.local avec vos paramètres

# Démarrer le serveur de développement
pnpm dev

# Exécuter les tests
pnpm test
```

## Structure du Projet

```
├── client/                  # Frontend React
│   └── src/
│       ├── pages/          # Pages principales
│       ├── components/     # Composants réutilisables
│       └── lib/risk/       # Scoreurs ML
├── server/                 # Backend Express + tRPC
├── drizzle/               # Migrations et schéma DB
└── src/lib/risk/          # Logique métier partagée
```

## Pages Principales

| Page | Route | Description |
|------|-------|-------------|
| Accueil | `/` | Présentation et navigation |
| Hub | `/hub` | Sélection du type d'évaluation |
| Particulier | `/individual` | Formulaire d'évaluation individuelle |
| Entreprise | `/company` | Formulaire d'évaluation entreprise |
| Dashboard | `/dashboard` | Tableau de bord analytique |

## API tRPC

### Scoring

```typescript
// Évaluer un particulier
POST /trpc/risk.scoreIndividual
Input: {
  age?: number
  monthly_income?: number
  credit_utilization_ratio?: number
  debt_to_income_ratio?: number
  open_credit_lines?: number
  times_90_days_late?: number
  times_60_89_days_late?: number
  times_30_59_days_late?: number
  real_estate_loans?: number
  number_of_dependents?: number
}

// Évaluer une entreprise
POST /trpc/risk.scoreCompany
Input: {
  common_equity_ratio?: number
  loan_loss_provisions?: number
  cost_to_income?: number
  roe?: number
  liq_assets_ratio?: number
  size_log_assets?: number
  working_capital_ratio?: number
  retained_earnings_ratio?: number
  ebit_ratio?: number
  equity_to_debt?: number
  sales_ratio?: number
  capital_adequacy_ratio?: number
  leverage_ratio?: number
  lcr?: number
  debt_service_coverage?: number
  net_profit_margin?: number
}
```

### Récupération des Données

```typescript
// Obtenir les statistiques
GET /trpc/risk.getStats
Output: {
  total: number
  avgScore: number
  recent: Assessment[]
}

// Obtenir l'historique complet
GET /trpc/risk.getHistory
Output: Assessment[]
```

## Modèles de Machine Learning

### Scoring Individuel
- **Modèle** : Régression Logistique
- **Facteurs** : 10 variables financières et comportementales
- **Sortie** : Score de risque (0-100) + Probabilité de défaut

### Scoring Entreprise
- **Modèle** : Régression Logistique + Analyses Financières
- **Facteurs** : 16 ratios financiers
- **Sortie** : Score de risque + Z-Score Altman + Conformité Basel III

## Tests

```bash
# Exécuter tous les tests
pnpm test

# Tests disponibles (13 total)
# - 5 tests scoring individuel
# - 7 tests scoring entreprise
# - 1 test authentification
```

## Configuration

### Variables d'Environnement

```env
# Base de données
DATABASE_URL=mysql://user:password@localhost:3306/credit_risk

# OAuth
MANUS_CLIENT_ID=your-client-id
MANUS_CLIENT_SECRET=your-client-secret

# Serveur
NODE_ENV=development
PORT=3000
```

## Déploiement

### Build Production

```bash
pnpm build
pnpm start
```

### Docker (optionnel)

```bash
docker build -t credit-risk-app .
docker run -p 3000:3000 credit-risk-app
```

## Documentation Complète

Voir [DOCUMENTATION.md](./DOCUMENTATION.md) pour :
- Architecture technique détaillée
- Guide d'utilisation complet
- Référence API complète
- Guide de déploiement
- Dépannage

## Statut du Projet

- ✓ Scoring ML (individuel et entreprise)
- ✓ Analyses avancées (Altman, Basel III)
- ✓ Interface utilisateur complète
- ✓ Persistance des données
- ✓ Tableau de bord analytique
- ✓ Tests unitaires (13/13 passants)
- ✓ Documentation complète

**Prêt pour la production** ✓

## Support

Pour toute question ou problème, consultez :
1. [DOCUMENTATION.md](./DOCUMENTATION.md) - Guide complet
2. [todo.md](./todo.md) - Historique des tâches
3. Tests unitaires dans `server/*.test.ts`

## Licence

Propriétaire - Tous droits réservés

---

**Version** : 1.0.0  
**Date** : 2026-04-07  
**Statut** : Production Ready
