# Guide de Démarrage Rapide

## Installation (5 minutes)

### 1. Prérequis

- Node.js 22.13.0 ou supérieur
- pnpm 10.4.1 ou supérieur
- MySQL 8.0 ou supérieur

Vérifier l'installation :
```bash
node --version   # v22.13.0+
pnpm --version   # 10.4.1+
mysql --version  # 8.0+
```

### 2. Cloner et Installer

```bash
# Cloner le repository
git clone <repository-url>
cd credit-risk-app

# Installer les dépendances
pnpm install
```

### 3. Configuration

```bash
# Créer le fichier .env.local
cp .env.example .env.local

# Éditer .env.local avec vos paramètres
nano .env.local
```

**Variables requises :**
```env
DATABASE_URL=mysql://user:password@localhost:3306/credit_risk
MANUS_CLIENT_ID=your-client-id
MANUS_CLIENT_SECRET=your-client-secret
```

### 4. Base de Données

```bash
# Exécuter les migrations
pnpm drizzle-kit migrate

# Ou manuellement :
mysql -u user -p credit_risk < drizzle/migrations/0000_new_venus.sql
mysql -u user -p credit_risk < drizzle/migrations/0001_add_assessments.sql
```

### 5. Démarrer

```bash
# Mode développement
pnpm dev

# L'application sera accessible sur http://localhost:5173
```

## Utilisation

### Évaluer un Particulier

1. Aller sur http://localhost:5173
2. Cliquer sur "Évaluer un Particulier"
3. Remplir le formulaire avec les informations :
   - Âge
   - Revenu mensuel
   - Utilisation du crédit
   - Historique de paiement
   - Autres informations
4. Cliquer sur "Évaluer"
5. Voir le résultat avec score, niveau de risque et facteurs

### Évaluer une Entreprise

1. Aller sur http://localhost:5173
2. Cliquer sur "Évaluer une Entreprise"
3. Remplir le formulaire avec les ratios financiers
4. Cliquer sur "Évaluer"
5. Voir le résultat incluant :
   - Score de risque ML
   - Z-Score d'Altman
   - Conformité Basel III

### Consulter le Tableau de Bord

1. Cliquer sur "Tableau de Bord" depuis l'accueil
2. Voir les statistiques :
   - Total d'évaluations
   - Score moyen
   - Graphiques de tendance
   - Historique complet

## Tests

```bash
# Exécuter tous les tests
pnpm test

# Mode watch (re-exécute à chaque changement)
pnpm test:watch

# Résultat attendu : 13 tests passants
```

## Développement

### Structure des Fichiers

```
client/src/
├── pages/              # Pages React
├── components/         # Composants réutilisables
├── lib/               # Utilitaires
│   └── risk/          # Scoreurs ML
└── main.tsx           # Point d'entrée

server/
├── routers.ts         # Routes tRPC
├── db.ts             # Accès à la base de données
└── _core/            # Configuration

drizzle/
├── schema.ts         # Définition des tables
└── migrations/       # Fichiers SQL
```

### Ajouter une Nouvelle Évaluation

1. Créer le formulaire dans `client/src/pages/`
2. Ajouter la logique de scoring dans `src/lib/risk/`
3. Ajouter l'endpoint tRPC dans `server/routers.ts`
4. Ajouter les tests dans `server/*.test.ts`

### Modifier les Modèles ML

Les poids des modèles sont stockés dans :
- `src/lib/risk/individual_scoring_weights.json`
- `src/lib/risk/company_scoring_weights.json`

Pour mettre à jour :
1. Remplacer le fichier JSON
2. Exécuter les tests : `pnpm test`
3. Vérifier que les résultats sont cohérents

## Build Production

```bash
# Créer le build optimisé
pnpm build

# Démarrer le serveur de production
pnpm start

# L'application sera accessible sur http://localhost:3000
```

## Dépannage

### Erreur : "Cannot find module 'riskAssessment'"

**Solution** : Vérifier que le fichier `src/lib/risk/riskAssessment.ts` existe.

```bash
ls -la src/lib/risk/riskAssessment.ts
```

### Erreur : "Database connection failed"

**Solution** : Vérifier la variable `DATABASE_URL` et que MySQL est accessible.

```bash
# Tester la connexion
mysql -u user -p -h localhost -D credit_risk -e "SELECT 1;"
```

### Erreur : "OAuth not configured"

**Solution** : Vérifier que `MANUS_CLIENT_ID` et `MANUS_CLIENT_SECRET` sont configurés dans `.env.local`.

### Tests qui échouent

**Solution** : Vérifier que tous les fichiers ML existent.

```bash
ls -la src/lib/risk/*.json
ls -la src/lib/risk/*.ts
```

## Commandes Utiles

```bash
# Installer les dépendances
pnpm install

# Démarrer en développement
pnpm dev

# Exécuter les tests
pnpm test

# Build production
pnpm build

# Démarrer la production
pnpm start

# Format du code
pnpm format

# Lint du code
pnpm lint

# Générer les migrations
pnpm drizzle-kit generate

# Exécuter les migrations
pnpm drizzle-kit migrate
```

## Prochaines Étapes

1. **Authentification** : Configurer OAuth Manus
2. **Base de Données** : Exécuter les migrations
3. **Tests** : Vérifier que tous les tests passent
4. **Déploiement** : Déployer en production

## Ressources

- [Documentation Complète](./DOCUMENTATION.md)
- [README Principal](./README.md)
- [Historique des Tâches](./todo.md)
- [Tests Unitaires](./server/)

## Support

Pour toute question, consultez la [documentation complète](./DOCUMENTATION.md).

---

**Prêt à démarrer !** 🚀
