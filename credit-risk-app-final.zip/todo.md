# Credit Risk App - TODO

## Phase 1: ML Integration
- [x] Copier les fichiers ML (individualRiskScorer, companyRiskScorer)
- [x] Copier les fichiers de poids JSON
- [x] Copier le hook useRiskAssessment
- [x] Intégrer le riskRouter dans le backend tRPC
- [x] Configurer tsconfig.json pour resolveJsonModule

## Phase 2: Pages et Navigation
- [x] Créer la page Hub centrale (RiskHub.tsx)
- [x] Créer la page d'évaluation pour particuliers (IndividualAssessment.tsx)
- [x] Créer la page d'évaluation pour entreprises (CompanyAssessment.tsx)
- [x] Créer la page Dashboard analytique (Dashboard.tsx)
- [x] Mettre à jour App.tsx avec les routes
- [x] Créer la page Home d'accueil professionnelle

## Phase 3: Formulaires d'Évaluation
- [x] Créer le formulaire pour particuliers avec validation
- [x] Créer le formulaire pour entreprises avec validation
- [x] Implémenter la soumission des formulaires
- [x] Ajouter les états de loading et erreur

## Phase 4: Affichage des Résultats
- [x] Créer le composant d'affichage du score de risque
- [x] Implémenter la jauge visuelle du score
- [x] Afficher les facteurs contributifs
- [x] Implémenter les calculs Basel III pour entreprises
- [x] Afficher le Z-Score d'Altman pour entreprises

## Phase 5: Design et UI
- [x] Améliorer le design global (version professionnelle)
- [x] Créer une palette de couleurs neutres
- [x] Implémenter la typographie claire
- [x] Supprimer tous les emojis
- [x] Ajouter les états vides (empty states)
- [x] Ajouter les animations et transitions

## Phase 6: Tests et Optimisation
- [x] Tester les formulaires individuels
- [x] Tester les formulaires entreprises
- [x] Tester le scoring ML
- [x] Tester la navigation
- [x] Optimiser les performances
- [x] Vérifier la responsivité mobile

## Phase 7: Tableau de Bord
- [x] Implémenter le stockage des résultats en base de données
- [x] Créer les graphiques Recharts pour le dashboard
- [x] Ajouter les métriques clés
- [x] Implémenter l'historique des évaluations

## Phase 8: Livraison
- [x] Créer le checkpoint final
- [x] Préparer la documentation
- [x] Livrer le projet au client
